# TODO

Name = input("What is your name? ")
print("Hello,", Name)